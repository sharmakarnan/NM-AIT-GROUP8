GRANT ALL PRIVILEGES ON *.* TO 'mysqluser'@'%';
