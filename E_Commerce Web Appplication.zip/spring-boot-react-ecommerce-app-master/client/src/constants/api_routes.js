export const HOME_PAGE_DATA_API = "/home";
export const TABS_DATA_API = "/tabs";
export const PRODUCT_BY_ID_DATA_API = "/products?product_id=";
export const PRODUCT_BY_CATEGORY_DATA_API = "/products";
export const SEARCH_SUGGESTION_API = "/search-suggestion?q=";
export const DEFAULT_SEARCH_SUGGESTION_API = "/default-search-suggestion";
export const FILTER_ATTRIBUTES_API = "/filter";